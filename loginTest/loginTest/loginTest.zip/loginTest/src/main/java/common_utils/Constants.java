package common_utils;

public class Constants {
    public static final String FB_URL = "https://www.facebook.com/";
    public static final String EXPECTED_ERROR_MSG="The password you’ve entered is incorrect. Forgot Password?";

}
